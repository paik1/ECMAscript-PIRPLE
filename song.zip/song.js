/*
 * Below are the attributes to one of my favourite song
 * The name of this song is "Makasam" by the Indian artist kr$na
 */

// Logging out the input

var songName = "Makasam";
var yearReleased = "2020";
var artist = "Kr$na";
var artistLogo = "$";
var songLength = 5.38;
var views = 7006957;
var label = "Kalamkaar";
var genre = "hip-hop";
var likes = 206000;
var artistActive = true;

console.log(songName);
console.log(yearReleased);
console.log(artist);
console.log(artistLogo);
console.log(songLength);
console.log(views);
console.log(label);
console.log(genre);
console.log(likes);
console.log(artistActive);
